﻿using System;

namespace PackageLicenseFile
{
    public class Class1
    {
    }
}
