﻿using System;

namespace ComplexLicense
{
    public class Class1
    {
    }
}
