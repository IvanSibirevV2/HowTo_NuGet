Authoring, contains an example which tells how to author a NuGet package to transform web.config and appconfig.config files using .transform file through msbuild targets.

Consuming, contains an example which tells how to consume a package with PackageReference which transform xml files like web.config or appconfig.config through mabuild targets.
