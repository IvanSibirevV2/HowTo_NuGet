﻿using System;

namespace PackageIconExample
{
    public class Class1
    {
    }
}
