﻿using System;

namespace PackageLicenseFileNuspecExample
{
    public class Class1
    {
    }
}
