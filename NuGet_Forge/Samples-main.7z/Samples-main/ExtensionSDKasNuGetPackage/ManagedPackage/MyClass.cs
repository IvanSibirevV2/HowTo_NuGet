﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagedPackage
{
    /// <summary>
    /// MyClass
    /// </summary>
    public sealed class MyClass
    {
        /// <summary>
        /// MyData
        /// </summary>
        public string MyData
        {
            get;
            set;
        }
    }
}
