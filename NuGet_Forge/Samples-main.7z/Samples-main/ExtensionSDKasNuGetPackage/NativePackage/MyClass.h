﻿#pragma once

namespace NativePackage
{
    public ref class Class1 sealed
    {
    public:
        Class1();
    };
}
