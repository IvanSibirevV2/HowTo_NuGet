﻿#include "pch.h"
#include "MyClass.h"

using namespace NativePackage;
using namespace Platform;

Class1::Class1()
{
}
