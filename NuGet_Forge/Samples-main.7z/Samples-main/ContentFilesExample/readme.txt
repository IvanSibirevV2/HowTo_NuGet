authoring contains everything needed to create a content v2 package. Run authoring/pack.ps1 to create ContentFilesExample1.0.0.nupkg

consuming contains an example project that uses contentFiles from ContentFilesExample 1.0.0.






