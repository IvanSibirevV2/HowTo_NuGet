#!/usr/bin/env bash
echo ""This is an example script that will be copied to the build output folder under tools."