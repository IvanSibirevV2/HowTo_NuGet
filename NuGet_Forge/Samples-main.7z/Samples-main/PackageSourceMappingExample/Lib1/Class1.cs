﻿using System;

namespace Lib1
{
    public class Class1
    {
    }
}
