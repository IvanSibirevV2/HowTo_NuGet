﻿using System;

namespace Lib2
{
    public class Class1
    {
    }
}
