﻿namespace ClassLibraryWithTransitivePinning
{
    public class Class1
    {

    }
}