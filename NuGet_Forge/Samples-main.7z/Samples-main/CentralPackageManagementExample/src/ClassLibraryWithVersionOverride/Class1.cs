﻿namespace ClassLibraryWithVersionOverride
{
    public class Class1
    {

    }
}