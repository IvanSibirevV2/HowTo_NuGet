﻿using System;

namespace PackageIconNuspecExample
{
    public class Class1
    {
    }
}
