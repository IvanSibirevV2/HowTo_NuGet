﻿using System;

namespace Library
{
    public class Lib
    {
        public int ClassLibNumber()
        {
            return 2;
        }
    }
}
