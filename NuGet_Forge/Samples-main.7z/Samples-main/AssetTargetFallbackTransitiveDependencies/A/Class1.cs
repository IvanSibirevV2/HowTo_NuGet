﻿namespace A;
public class Class1
{

}
